export const Footer = () => {
  return (
    <footer className="text-center p-3 text-white bg-indigo-700">
      <small>&copy; Web World Creators 株式会社</small>
    </footer>
  );
};
